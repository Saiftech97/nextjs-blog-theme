import { Menu, Bell, User } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../auth/AuthProvider';

export default function Header() {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const { user, signOut } = useAuth();

  return (
    <header className="bg-white shadow-sm lg:static lg:overflow-y-visible">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative flex justify-between h-16">
          <div className="flex items-center lg:hidden">
            <button
              type="button"
              className="-mr-3 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900"
            >
              <span className="sr-only">Open sidebar</span>
              <Menu className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>

          <div className="flex items-center justify-end flex-1 gap-4">
            <button
              type="button"
              className="flex-shrink-0 rounded-full p-1 text-gray-400 hover:text-gray-500"
            >
              <span className="sr-only">Notifications</span>
              <Bell className="h-6 w-6" aria-hidden="true" />
            </button>

            <div className="relative">
              <button
                type="button"
                className="flex items-center max-w-xs rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
              >
                <span className="sr-only">Open user menu</span>
                <User className="h-8 w-8 rounded-full bg-gray-100 p-1" aria-hidden="true" />
              </button>

              {showProfileMenu && (
                <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white ring-1 ring-black ring-opacity-5">
                  <button
                    onClick={() => signOut()}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    Déconnexion
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}