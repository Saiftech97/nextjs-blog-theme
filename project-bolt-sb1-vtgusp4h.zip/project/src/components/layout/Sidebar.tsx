import { NavLink } from 'react-router-dom';
import { Car, PenTool as Tool, Fuel, BookOpen, BarChart3, Settings, LogOut } from 'lucide-react';
import { useAuth } from '../auth/AuthProvider';

const navigation = [
  { name: 'Tableau de bord', href: '/', icon: BarChart3 },
  { name: 'Flotte', href: '/fleet', icon: Car },
  { name: 'Maintenance', href: '/maintenance', icon: Tool },
  { name: 'Carburant', href: '/fuel', icon: Fuel },
  { name: 'Réservations', href: '/reservations', icon: BookOpen },
  { name: 'Rapports', href: '/reports', icon: BarChart3 },
  { name: 'Paramètres', href: '/settings', icon: Settings },
];

export default function Sidebar() {
  const { signOut } = useAuth();

  return (
    <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col">
      <div className="flex flex-col flex-grow bg-white pt-5 pb-4 overflow-y-auto">
        <div className="flex items-center flex-shrink-0 px-4">
          <Car className="h-8 w-8 text-blue-600" />
          <span className="ml-3 text-lg font-semibold text-gray-900">
            FleetManager Pro
          </span>
        </div>
        <nav className="mt-5 flex-1 flex flex-col divide-y divide-gray-200 overflow-y-auto" aria-label="Sidebar">
          <div className="px-2 space-y-1">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) => 
                  `group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                    isActive
                      ? 'bg-gray-100 text-gray-900'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`
                }
              >
                <item.icon
                  className="mr-3 flex-shrink-0 h-6 w-6"
                  aria-hidden="true"
                />
                {item.name}
              </NavLink>
            ))}
          </div>
        </nav>
        <div className="mt-auto p-4">
          <button
            onClick={() => signOut()}
            className="w-full flex items-center px-2 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50 hover:text-gray-900"
          >
            <LogOut className="mr-3 flex-shrink-0 h-6 w-6" aria-hidden="true" />
            Déconnexion
          </button>
        </div>
      </div>
    </div>
  );
}