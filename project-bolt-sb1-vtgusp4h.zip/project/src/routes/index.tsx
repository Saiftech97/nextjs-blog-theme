import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../components/auth/AuthProvider';
import Login from '../pages/auth/Login';
import Dashboard from '../pages/Dashboard';
import FleetManagement from '../pages/fleet/FleetManagement';
import VehicleDetails from '../pages/fleet/VehicleDetails';
import Maintenance from '../pages/maintenance/Maintenance';
import FuelManagement from '../pages/fuel/FuelManagement';
import Reservations from '../pages/reservations/Reservations';
import Reports from '../pages/reports/Reports';
import Settings from '../pages/settings/Settings';
import Layout from '../components/layout/Layout';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
    </div>;
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
}

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      
      <Route path="/" element={
        <PrivateRoute>
          <Layout />
        </PrivateRoute>
      }>
        <Route index element={<Dashboard />} />
        <Route path="fleet" element={<FleetManagement />} />
        <Route path="fleet/:id" element={<VehicleDetails />} />
        <Route path="maintenance" element={<Maintenance />} />
        <Route path="fuel" element={<FuelManagement />} />
        <Route path="reservations" element={<Reservations />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}