export interface Position {
  lat: number;
  lng: number;
  lastUpdate: string;
}

export interface FuelInfo {
  niveau: number;
  consommation: number;
  dernierPlein: string;
  coutTotal: number;
  transactions: {
    date: string;
    montant: number;
    litres: number;
    stationService: string;
  }[];
}

export interface MaintenanceRecord {
  prochaineRevision: string;
  alertes: string[];
  historiqueEntretien: {
    date: string;
    type: string;
    description: string;
    cout: number;
    pieces: {
      nom: string;
      quantite: number;
      cout: number;
    }[];
    technicien: string;
  }[];
  documentsAssocies: {
    nom: string;
    url: string;
    date: string;
  }[];
}

export interface Reservation {
  id: string;
  debut: string;
  fin: string;
  conducteur: string;
  statut: 'confirmée' | 'en_attente' | 'terminée' | 'annulée';
  destination?: string;
  motif?: string;
  commentaires?: string;
}

export interface Vehicle {
  id: string;
  immatriculation: string;
  marque: string;
  modele: string;
  kilometrage: number;
  statut: 'disponible' | 'en_service' | 'maintenance';
  conducteur?: string;
  dateAchat: string;
  dateMiseEnService: string;
  assurance: {
    numero: string;
    dateExpiration: string;
    compagnie: string;
  };
  controlesTechniques: {
    date: string;
    resultat: 'conforme' | 'non_conforme';
    prochainControle: string;
  }[];
  documents: {
    type: string;
    numero: string;
    dateExpiration: string;
  }[];
  position: Position;
  carburant: FuelInfo;
  maintenance: MaintenanceRecord;
  reservations: Reservation[];
  analytics: {
    coutTotal: number;
    consommationMoyenne: number;
    distanceParcourue: number;
    tempsUtilisation: number;
    incidents: number;
  };
}

export interface User {
  id: string;
  nom: string;
  prenom: string;
  email: string;
  role: 'admin' | 'manager' | 'conducteur';
  permis: {
    numero: string;
    dateExpiration: string;
    type: string[];
  };
  vehiculesAutorises: string[];
  historiqueReservations: string[];
}

export interface Incident {
  id: string;
  vehiculeId: string;
  date: string;
  type: 'accident' | 'panne' | 'maintenance' | 'autre';
  description: string;
  statut: 'ouvert' | 'en_cours' | 'resolu';
  priorite: 'basse' | 'moyenne' | 'haute';
  coutEstime?: number;
  coutReel?: number;
  documentsAssocies: {
    nom: string;
    url: string;
    type: string;
  }[];
}

export interface Rapport {
  id: string;
  date: string;
  type: 'quotidien' | 'hebdomadaire' | 'mensuel' | 'personnalise';
  contenu: {
    couts: {
      carburant: number;
      maintenance: number;
      reparations: number;
      total: number;
    };
    utilisation: {
      kilometresParcourus: number;
      heuresUtilisation: number;
      tauxUtilisation: number;
    };
    incidents: {
      nombre: number;
      coutTotal: number;
      tempsArret: number;
    };
    vehicules: {
      id: string;
      metrics: {
        utilisation: number;
        couts: number;
        incidents: number;
      };
    }[];
  };
}