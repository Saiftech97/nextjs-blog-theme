/*
  # Initial Fleet Management Schema

  1. Tables
    - users: Store user information and roles
    - vehicles: Main vehicle information
    - maintenance_records: Vehicle maintenance history
    - fuel_transactions: Fuel purchase records
    - reservations: Vehicle booking system
    - incidents: Track vehicle incidents and issues
    - reports: System reports and analytics

  2. Security
    - Enable RLS on all tables
    - Policies for role-based access
    - Secure data access patterns
*/

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  nom TEXT NOT NULL,
  prenom TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'manager', 'conducteur')),
  permis_numero TEXT,
  permis_expiration DATE,
  permis_types TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vehicles table
CREATE TABLE vehicles (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  immatriculation TEXT UNIQUE NOT NULL,
  marque TEXT NOT NULL,
  modele TEXT NOT NULL,
  kilometrage INTEGER NOT NULL DEFAULT 0,
  statut TEXT NOT NULL CHECK (statut IN ('disponible', 'en_service', 'maintenance')),
  conducteur_id uuid REFERENCES users(id),
  date_achat DATE NOT NULL,
  date_mise_en_service DATE NOT NULL,
  assurance_numero TEXT,
  assurance_expiration DATE,
  assurance_compagnie TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Maintenance records
CREATE TABLE maintenance_records (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_id uuid REFERENCES vehicles(id) NOT NULL,
  date DATE NOT NULL,
  type TEXT NOT NULL,
  description TEXT,
  cout DECIMAL(10,2),
  technicien TEXT,
  prochaine_revision DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Fuel transactions
CREATE TABLE fuel_transactions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_id uuid REFERENCES vehicles(id) NOT NULL,
  date TIMESTAMPTZ NOT NULL,
  litres DECIMAL(10,2) NOT NULL,
  cout_total DECIMAL(10,2) NOT NULL,
  station_service TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reservations
CREATE TABLE reservations (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_id uuid REFERENCES vehicles(id) NOT NULL,
  user_id uuid REFERENCES users(id) NOT NULL,
  debut TIMESTAMPTZ NOT NULL,
  fin TIMESTAMPTZ NOT NULL,
  statut TEXT NOT NULL CHECK (statut IN ('confirmée', 'en_attente', 'terminée', 'annulée')),
  destination TEXT,
  motif TEXT,
  commentaires TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Incidents
CREATE TABLE incidents (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  vehicle_id uuid REFERENCES vehicles(id) NOT NULL,
  date TIMESTAMPTZ NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('accident', 'panne', 'maintenance', 'autre')),
  description TEXT,
  statut TEXT NOT NULL CHECK (statut IN ('ouvert', 'en_cours', 'resolu')),
  priorite TEXT NOT NULL CHECK (priorite IN ('basse', 'moyenne', 'haute')),
  cout_estime DECIMAL(10,2),
  cout_reel DECIMAL(10,2),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reports
CREATE TABLE reports (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  date TIMESTAMPTZ NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('quotidien', 'hebdomadaire', 'mensuel', 'personnalise')),
  contenu JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE maintenance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE fuel_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view their own data"
  ON users
  FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all users"
  ON users
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );

CREATE POLICY "Public vehicles read access"
  ON vehicles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Managers and admins can modify vehicles"
  ON vehicles
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role IN ('admin', 'manager')
    )
  );

-- Functions
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_vehicles_updated_at
  BEFORE UPDATE ON vehicles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_reservations_updated_at
  BEFORE UPDATE ON reservations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_incidents_updated_at
  BEFORE UPDATE ON incidents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();